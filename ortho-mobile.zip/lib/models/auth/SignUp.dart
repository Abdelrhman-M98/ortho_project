// ignore_for_file: file_names

class SignUp {
  String continuationKey;
  String password;

  SignUp({required this.continuationKey, required this.password});
}
