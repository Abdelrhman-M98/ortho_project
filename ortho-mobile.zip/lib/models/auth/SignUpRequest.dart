// ignore_for_file: file_names

class SignUpRequest {
  String email;
  String name;

  SignUpRequest({required this.email, required this.name});
}
