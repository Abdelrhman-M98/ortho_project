// ignore_for_file: file_names

class Diagnosis {
  final String name;
  final List<String> subcategories;

  Diagnosis(this.name, this.subcategories);
}

