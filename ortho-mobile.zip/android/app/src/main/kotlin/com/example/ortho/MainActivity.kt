package com.example.ortho

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
